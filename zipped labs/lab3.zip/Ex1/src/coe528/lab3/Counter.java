/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package coe528.lab3;

/**
 *
 * @author notiz
 */
public interface Counter {
    String count();
    void increment();
    void decrement();
    void reset();
}
